#!/bin/bash

outdir="results"
count=0
total_cache_budget=128
for l1d_size in 4 8 16 32 64
do
  for l1d_assoc in 1 2 3 4 5 6 7 8
  do
    for l1i_size in 4 8 16 32 64
    do
      for l1i_assoc in 1 2 3 4 5 6 7 8
      do
        if [ $((l1d_size + l1i_size)) -le $total_cache_budget ]
        then
            if (( l1d_size <= 8 )); then
                l1d_data_latency=1
            elif (( l1d_size <= 32 )); then
                l1d_data_latency=2
            elif (( l1d_size = 64 )); then
                l1d_data_latency=4
            else 
                l1d_data_latency=6
            fi
            if (( l1i_size <= 8 )); then
                l1i_data_latency=1
            elif (( l1i_size <= 32 )); then
                l1i_data_latency=2
            elif (( l1i_size = 64 )); then
                l1i_data_latency=4
            else 
                l1i_data_latency=6
            fi
            ((count+=1))
            cmd="build/ARM/gem5.opt"
            cmd+=" --outdir=statsQ2___A"
            cmd+=" --stats-file=stats_sim-${count}.txt"
            cmd+=" configs/example/se.py"
            cmd+=" -I 10000000"
            cmd+=" --cpu-type=DerivO3CPU"
            cmd+=" --sys-clock=2GHz"
            cmd+=" --cpu-clock=2GHz"
            cmd+=" --caches"
            cmd+=" --l1d_size=${l1d_size}kB"
            cmd+=" --l1d_data_latency=${l1d_data_latency}"
            cmd+=" --l1d_assoc=${l1d_assoc}"
            cmd+=" --l1i_size=${l1i_size}kB"
            cmd+=" --l1i_data_latency=${l1i_data_latency}"
            cmd+=" --l1i_assoc=${l1i_assoc}"
            cmd+=" --cmd=se-benchmarks/se-benchmarks/RealMM_arm.out"
            echo "Running simulation ${count} with configuration: L1D Size=${l1d_size}kB, L1D Assoc=${l1d_assoc}, L1I Size=${l1i_size}kB, L1I Assoc=${l1i_assoc}"
            $cmd
        fi    
      done
    done
  done
done