#!/bin/bash

outdir="results"
count=0


for l1_size in 4 8 16 32 64 128 256
do
  for l1_assoc in 1 2 3 4
  do
    for l2_size in 128 256 512 1024 2048 4096 8192
    do
      for l2_assoc in 4 5 6 7 8
      do
        if (( l1_size <= 8 )); then
          l1_data_latency=1
        elif (( l1_size <= 32 )); then
          l1_data_latency=2
        elif (( l1_size = 64 )); then
          l1_data_latency=4
        elif (( l1_size = 128 )); then
          l1_data_latency=6
        else
          l1_data_latency=10
        fi
        if (( l2_size = 128 )); then
          l2_data_latency=6
        elif (( l2_size = 256 )); then
          l2_data_latency=10
        elif (( l2_size = 512 )); then
          l2_data_latency=12
        elif (( l2_size = 1024 )); then
          l2_data_latency=16
        elif (( l2_size = 2048 )); then
          l2_data_latency=20
        elif (( l2_size = 4096 )); then
          l2_data_latency=32
        else
          l2_data_latency=44
        fi
        ((count+=1))
        cmd="build/X86/gem5.opt"
        cmd+=" --outdir=Q1__B"
        cmd+=" --stats-file=stats_sim-${count}.txt"
        cmd+=" configs/example/se.py"
        cmd+=" -I 10000000"
        cmd+=" --cpu-type=DerivO3CPU"
        cmd+=" --sys-clock=2GHz"
        cmd+=" --cpu-clock=2GHz"
        cmd+=" --caches"
        cmd+=" --l2cache"
        cmd+=" --l1d_size=${l1_size}kB"
        cmd+=" --l1d_data_latency=${l1_data_latency}"
        cmd+=" --l1d_assoc=${l1_assoc}"
        cmd+=" --l1i_size=${l1_size}kB"
        cmd+=" --l1i_data_latency=${l1_data_latency}"
        cmd+=" --l1i_assoc=${l1_assoc}"
        cmd+=" --l2_size=${l2_size}kB"
        cmd+=" --l2_data_latency=${l2_data_latency}"
        cmd+=" --l2_assoc=${l2_assoc}"
        cmd+=" --cmd=se-benchmarks/se-benchmarks/Oscar_x86.out"
        echo "count ${count} L1 size ${l1_size}, L1 assoc ${l1_assoc}, L2 size ${l2_size}, L2 assoc ${l2_assoc}" >> simulation.txt
        $cmd
      done
    done
  done
done