#ifndef TOP_H
#define TOP_H

#include "initiator.h"
#include "target.h"

SC_MODULE(Top)
{
  Initiator *initiator;
  Memory    *memory_0;
  Memory    *memory_1;

  SC_CTOR(Top)
  {
    // Instantiate components
    initiator = new Initiator("initiator");
    memory_0 = new Memory("memory_0", 0, 256);
    memory_1 = new Memory("memory_1", 256, 512);

    // For simplicity one initiator is bound 
    // directly to one target with no intervening bus
    // TODO: Bind initiator sockets to target sockets


  }

    void mem_dump(){
        memory_0->print_memory();
        memory_1->print_memory();
    }
};

#endif
