#ifndef TARGET_H
#define TARGET_H

// Needed for the simple_target_socket
#define SC_INCLUDE_DYNAMIC_PROCESSES

#include "systemc"
using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_target_socket.h"

// Target module representing a simple memory

struct Memory : sc_module {
  // TLM-2 socket, defaults to 32-bits wide, base protocol
  tlm_utils::simple_target_socket<Memory> socket;

  Memory(sc_module_name _name, sc_uint<64> sa, sc_uint<64> ml)
      : socket("socket"), mem_name(_name), start_addr(sa), mem_len(ml) {

    // Register callback for incoming b_transport interface method call
    socket.register_b_transport(this, &Memory::b_transport);

    // allocate on heap
    mem = (int *)malloc(sizeof(int) * mem_len);

    // Initialize memory with random data
    for (int i = 0; i < mem_len; i++)
      mem[i] = start_addr + i;
  }

  // TLM-2 blocking transport method implemented
  virtual void b_transport(tlm::tlm_generic_payload &trans, sc_time &delay) {
    // TODO: get tlm payload components
    // HINT: Be carefull! Copy pasting code from class may not work.
    // Also, your outputs from TLM and sysc should be identicle.
    // Use that to your advantage.
    // TODO: check if this memory module should respond to the received address
    // HINT: If the above TODOs are correctly implemented, the SC_REPORT_ERROR will
    // never execute. See how this was handled in the SystemC signals implemetation.

    // Obliged to check address range and check for unsupported features,
    //   i.e. byte enables, streaming, and bursts
    if (addr < start_addr || addr >= sc_dt::uint64(start_addr + mem_len) ||
        byt != 0 || len > 1 || wid < len) {
      SC_REPORT_ERROR(
          "TLM-2: target.h",
	  "Target does not support given generic payload transaction"
		      );
    }

    // Obliged to implement read and write commands
    if (cmd == tlm::TLM_READ_COMMAND) {
      *ptr = mem[addr - start_addr];
    } else if (cmd == tlm::TLM_WRITE_COMMAND) {
      mem[addr - start_addr] = *ptr;
    }

    // TODO: Obliged to set response status to indicate successful completion
  }

  void print_memory() {
    // Initialize memory with random data
    for (int i = 0; i < mem_len; i++) {
      cout << mem[i] << endl;
    }
    cout << endl;
  }

  // local variables
  sc_module_name mem_name;
  int start_addr, mem_len;
  int *mem;
};

#endif
