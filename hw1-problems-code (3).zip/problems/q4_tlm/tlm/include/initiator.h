#ifndef INITIATOR_H
#define INITIATOR_H

#include "constants.h"
#include "systemc"

using namespace sc_core;
using namespace sc_dt;
using namespace std;

#include "tlm.h"
#include "tlm_utils/simple_initiator_socket.h"

// Initiator module generating generic payload transactions

struct Initiator : sc_module {

  // TLM-2 socket base protocol
  tlm_utils::simple_initiator_socket<Initiator> socket_0;
  tlm_utils::simple_initiator_socket<Initiator> socket_1;

  SC_CTOR(Initiator): socket_0("socket_0"), socket_1("socket_1") // Construct and name socket
  {
    // call thge thread process function when this class is initialized
    SC_THREAD(thread_process);
  }

  void thread_process() {
    // TLM-2 generic payload transaction, reused across calls to b_transport
    // trans allows for transaction between two components
    tlm::tlm_generic_payload *trans = new tlm::tlm_generic_payload;

    // Generate a random sequence of reads and writes
    for (int j = 0; j < NUM_ITER; j++) {
      for (int i = 0; i < 768; i++) {

        data = 99;

        if (i % 10 == 0) {
          cmd = tlm::TLM_WRITE_COMMAND;
        } else {
          cmd = tlm::TLM_READ_COMMAND;
        }

        // TODO: setup the generic payload

        // TODO: socket b_transport call with delay

        // Initiator obliged to check response status and delay
        if (trans->is_response_error())
          SC_REPORT_ERROR("TLM-2", "Response error from b_transport");

        // Realize the delay annotated onto the transport call
        wait(delay);
      }
    }
  }

  // Internal data buffer used by initiator with generic payload
  sc_time delay = sc_time(10, SC_NS);
  tlm::tlm_command cmd;
  int data;
  int addr;
};

#endif
