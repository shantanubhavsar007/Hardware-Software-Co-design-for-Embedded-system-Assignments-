#define WRITE_CMD 0
#define READ_CMD 1

#define NUM_ITER 100

#define DATA_MAX 256

#define DEBUG false
