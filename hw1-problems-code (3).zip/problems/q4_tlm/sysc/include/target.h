#ifndef TARGET_H
#define TARGET_H

#include "constants.h" // read write codes
#include <systemc.h>

using namespace sc_core;
using namespace sc_dt;
using namespace std;

// Target module representing a simple memory
struct Memory : sc_module {
  sc_in<bool> cmd_port;         
  sc_in<sc_uint<64> > addr_port; 
  sc_inout<sc_int<64> > data_port;

  SC_HAS_PROCESS(Memory);

  // // memory constructor, called by top
  Memory(sc_module_name _name, sc_uint<64> sa, sc_uint<64> ml)
      : mem_name(_name), start_addr(sa), mem_len(ml) {

    SC_METHOD(process_request);
    sensitive << cmd_port;
    sensitive << addr_port;

    // allocate on heap
    mem = (int *)malloc(sizeof(int) * mem_len);

    // Initialize memory with random data
    for (int k = 0; k < mem_len; k++) {
      mem[k] = start_addr + k;
    }
  }

  void process_request() {

    // read command
    cmd = cmd_port.read();

    // read address
    addr = addr_port.read();

    // do nothing if out of bounds
    // check if this memory module should respond to the received address
    if ((start_addr > addr) || ((start_addr + mem_len) <= addr))
      return; // not my address range

    // Obliged to implement read and write commands
    if ((cmd == READ_CMD)) {
      data_port.write(mem[addr - start_addr]); // write to port
    } else if (cmd == WRITE_CMD) {
      mem[addr - start_addr] = data_port.read(); // read from port
    }
  }

  void print_memory() {
    // Initialize memory with random data
    for (int i = 0; i < mem_len; i++) {
      cout << mem[i] << endl;
    }
    cout << endl;
  }

  // local variables
  sc_module_name mem_name;
  int start_addr, mem_len;
  int *mem;
  bool cmd;
  sc_dt::uint64 addr;
};

#endif
