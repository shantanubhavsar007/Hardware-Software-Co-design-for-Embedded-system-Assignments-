#ifndef INITIATOR_H
#define INITIATOR_H

#include "constants.h"
#include <systemc.h>

using namespace sc_core;
using namespace sc_dt;
using namespace std;

// Initiator module generating generic payload transactions
struct Initiator : sc_module {

  // decalre ports for the initiator
  sc_out<bool> cmd_port;
  sc_out<sc_uint<64> > addr_port;
  sc_inout<sc_int<64> > data_port;

  // initiator constructor, called by top
  SC_CTOR(Initiator) {
    // call thge thread process function when this class is initialized
    SC_THREAD(thread_process);
  }

  void thread_process() {

    // Generate a random sequence of reads and writes
    // jump 4 bytes every time
    for (int j = 0; j < NUM_ITER; j++) {
      for (int i = 0; i < 768; i++) {
        // write at certain locations
        if (i % 10 == 0)
          cmd = WRITE_CMD;
        else
          cmd = READ_CMD;

        // request read or write
        cmd_port.write(cmd); // write the command
        addr_port.write(i);  // write the address

        // if the command is write
        // create some data field 
        if (cmd == WRITE_CMD) {
          // generate random data
          data = 99;
          // write the data
          data_port.write(data);
        } else {
          data = data_port.read(); // read the data
        }

        wait(delay);
      }
    }
  }

  // local variables
  // NS delay between two transactions
  // this will be a blocking implementation
  sc_time delay = sc_time(10, SC_NS);
  bool cmd;
  int data;
};

#endif
