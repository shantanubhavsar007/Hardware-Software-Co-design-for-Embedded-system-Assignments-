#ifndef TOP_H
#define TOP_H

#include "initiator.h"
#include "target.h"

SC_MODULE(Top)
{
    Initiator *initiator;
    Memory *memory_0;
    Memory *memory_1;

    // create signals
    sc_signal<bool> *cmd_signal;
    sc_signal<sc_uint <64> > *addr_signal;
    sc_signal<sc_int <64>, SC_MANY_WRITERS> *data_signal;
    


    SC_CTOR(Top)
    {

        // Instantiate components
        initiator = new Initiator("initiator");
        memory_0 = new Memory("memory_0", 0, 256);
        // TODO: setup memory_1 similar to above
        memory_1 = new Memory("memory_1", 256, 750);

        // HINT: cmd, addr and signal lines are shared accross modules
        
        // TODO: initialize cmd signal and connect with ports
        cmd_signal =  new sc_signal<bool>;
        //cmd_signal = signal;
    
        initiator->cmd_port(*cmd_signal);
        memory_0->cmd_port(*cmd_signal);
        memory_1->cmd_port(*cmd_signal);

        // TODO: initialize addr signal and connect with ports
        addr_signal = new sc_signal<sc_uint <64> >;
        initiator->addr_port(*addr_signal);
        memory_0->addr_port(*addr_signal);
        memory_1->addr_port(*addr_signal);

        // TODO: initialize data signal and connect with ports
        data_signal = new sc_signal<sc_int <64>, SC_MANY_WRITERS>;
        initiator->data_port(*data_signal);
        memory_0->data_port(*data_signal);
        memory_1->data_port(*data_signal);

    }


    void mem_dump(){
        memory_0->print_memory();
        memory_1->print_memory();
    }
};

#endif
