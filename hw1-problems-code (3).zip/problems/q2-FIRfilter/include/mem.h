#ifndef MEM_H
#define MEM_H

#include <systemc.h>
#include "main.h"

//data to be sent
const double DATA[] = {30, 933, 225, 623, 526, 145, 842, 538,  \
        723, 386, 972, 817, 82, 14, 46, 73, 176, 957, 873,\
        465, 878, 670, 634, 988, 875, 700, 744, 478, 944, 718,\
        341, 290, 512, 649, 794, 720, 896, 316, 178, 195, 628,\
        425, 910, 652, 846, 950, 714, 927, 920, 490, 884, 235,\
        774, 233, 507, 896, 1, 122, 250, 259, 157, 227, 629,\
        427, 668, 760, 459, 115, 620, 759, 72, 535, 921, 766,\
        332, 285, 684, 139, 900, 389, 128, 884, 195, 406, 611,\
         44, 343, 42, 369, 551, 755, 603, 572, 709, 1001, 260,\
        865, 205, 324, 767, 531, 316, 961, 580, 884, 765, 274,\
        501, 639, 136, 184, 578, 593, 749, 111, 240, 814, 152,\
        601, 859, 992, 257, 120, 421, 203, 546, 75, 131 , 890, 89, 666, 111, 543, 342, 243, 121, 98 };

class Memory : public sc_module {
public:
    sc_in<bool> clock;
    sc_in<double> data_write;
    sc_out<double> data_read;

    void proc_memory();

    SC_HAS_PROCESS(Memory);
  
    Memory(sc_module_name _name) {

        SC_METHOD(proc_memory);
        sensitive << clock.pos();

        //memory initialization
        memory_size = sizeof (DATA) / sizeof (double);
        storage = new double[memory_size];
        for (i = 0; i < memory_size; i++) {
            storage[i] = DATA[i];
        }
    }

private:
    double * storage;
    int memory_size;
    int data_count;
    int i;
};

#endif
     
        
