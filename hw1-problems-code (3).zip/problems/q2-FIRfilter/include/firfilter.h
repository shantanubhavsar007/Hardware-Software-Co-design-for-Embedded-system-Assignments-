
#include <systemc.h>
double taps[14];

const double coef[14] = {472, 34, 348, 181, 295, 361, 430, 260, 179, 151, 81, 68,78, 302};

SC_MODULE(Firfilter){
  sc_in<bool> clock;
  sc_in<double> data_in;
  sc_out<double> data_out;
  


  void fir_main();

SC_CTOR( Firfilter ) {
  SC_CTHREAD(fir_main, clock.pos());
  //sensitive << clock.pos();
}
};


                             
                             
                             void Firfilter::fir_main()
                             {
                               //double taps[14];
                               data_out.write(0);
                               
                               //wait();
                               
                               while(true)
                               {
                                
                                 for(int i=14-1; i>0; i--)
                                 {
                                   taps[i] = taps[i-1];
                                 }
                                 
                                 taps[0] = data_in.read(); 

                                 double val = 0;
                                 for(int j = 0; j < 14; j++)
                                 {
                                   val = val + coef[j] * taps[j];
                                 }
                                 wait();
                                 data_out.write(val);
                                 
                               }
                             }
 
 

 

