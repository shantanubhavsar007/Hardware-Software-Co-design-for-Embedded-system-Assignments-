#include "mem.h"

void Memory::proc_memory() {
    // write down result of last cycle
    if ((data_count != memory_size)) {
        data_read->write(storage[data_count]);
        storage[data_count] = data_write->read();
        data_count++;
    } else if (data_count == memory_size) {
		cout << " memory size "<< memory_size<<endl;
        //print out content of memory (results)
        cout << sc_time_stamp() << "\t[MEMORY]: Data processed. Stop simulation..." << endl;
        cout << sc_time_stamp() << "\t[MEMORY]: Data in memory ([addr] data):" << endl;
        for (i = 0; i < memory_size; i++) {
            cout << "[" << i << "] ";
            cout.width(8);
            cout << storage[i] << "\t";
            if (i % 8 == 7) cout << endl;
        }
        //stop SystemC simulation
        sc_stop();
    }
 
}
