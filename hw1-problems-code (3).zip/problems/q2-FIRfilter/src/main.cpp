#include "systemc.h"
#include "mem.h"
#include "firfilter.h"
#include "main.h"

int sc_main(int argc, char* argv[]) {
    int i;

    //signals to connect data and mul ports
    sc_signal<double> data_sig;
    sc_signal<double> mul_sig;
    sc_signal<double> result;

    //system clock
    sc_clock* sys_clock;

    //pointer for modules
    Memory* mem;
    Firfilter* fir;


    // create global clock
    sys_clock = new sc_clock("SYSTEM_CLOCK", 1, SC_NS);
    
    //Construct Memory and Accumulator modules
    mem = new Memory("MEMORY");
    fir = new Firfilter("FIR");

    //connect ports of memory
    mem->data_read(data_sig);
    mem->clock(*sys_clock);
    mem->data_write(result);

    //[Missing] connect ports of fir_nodes
    fir->clock(*sys_clock);
    fir->data_in(data_sig);
    fir->data_out(result);

    //start simulation
    sc_start(300, SC_NS);
    return 0;
}
