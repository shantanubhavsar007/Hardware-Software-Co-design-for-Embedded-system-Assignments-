#ifndef __I2C_CONTROLLER_TB_H
#define __I2C_CONTROLLER_TB_H

#include <systemc.h>

#include <i2c_controller.h>
#include <i2c_slave_controller.h>

SC_MODULE(i2c_controller_tb)
{
	
	sc_clock *clk;
	sc_signal<bool> rst;
	sc_signal<sc_uint<7> > addr;
	sc_signal<sc_uint<8> > data_in;
	sc_signal<bool> enable;
	sc_signal<bool> rw;
	sc_signal<sc_lv<8> > data_out;
	sc_signal<bool> ready;
	sc_signal<sc_logic, SC_MANY_WRITERS> i2c_sda;
	sc_signal<sc_logic> i2c_scl;
	
	i2c_controller *master;
	i2c_slave_controller *slave_1;
	i2c_slave_controller *slave_2;
	i2c_slave_controller *slave_3;
	i2c_slave_controller *slave_4;
	//[Missing] slave_2 declaration
	
	SC_CTOR(i2c_controller_tb)
	{
		clk = new sc_clock("clk",2,SC_NS);
		
		master = new i2c_controller("i2c_controller");
			master->clk(*clk);
			master->rst(rst);
			master->addr(addr);
			master->data_in(data_in);
			master->enable(enable);
			master->rw(rw);
			master->data_out(data_out);
			master->ready(ready);
			master->i2c_sda(i2c_sda);
			master->i2c_scl(i2c_scl);
		
		slave_1 = new i2c_slave_controller("i2c_slave_controller_1", sc_lv<7>(42));
			slave_1->sda(i2c_sda);
			slave_1->scl(i2c_scl);
		
		slave_2 = new i2c_slave_controller("i2c_slave_controller_2", sc_lv<7>(43));
		slave_2->sda(i2c_sda);
		slave_2->scl(i2c_scl); //[Missing] create new slave_2 instance and connect to i2c_sda and i2c_scl
		// set the controller address based on the commented-out code in src/i2c_controller_tb.cpp
		
		slave_3 = new i2c_slave_controller("i2c_slave_controller_3", sc_lv<7>(44));
		slave_3->sda(i2c_sda);
		slave_3->scl(i2c_scl);
		
		slave_4 = new i2c_slave_controller("i2c_slave_controller_4", sc_lv<7>(45));
		slave_4->sda(i2c_sda);
		slave_4->scl(i2c_scl);
			
		SC_THREAD(stimuli);
	 	sensitive << *clk << rst;

	}
	
	~i2c_controller_tb()
	{
		delete master;
		delete slave_1;
		delete slave_2;
		delete slave_3;
		delete slave_4;// [Missing] delete slave_2
	}
	
	void stimuli();
	
};
#endif
