#include <systemc.h>

#include <i2c_controller_tb.h>

void i2c_controller_tb::stimuli()
{
    rst = 1;
    // slave 1
    wait(100, SC_NS);
    rst = 0;
    addr = 42;
    data_in = 170;
    rw = 0;
    enable = 1;
    
    wait(7, SC_NS);
    i2c_sda = (sc_logic)0;
    
    wait(10, SC_NS);
    enable = 0;
    wait(500, SC_NS);

    // write slave_2 driver code as per comments given below 
    addr=43;// [Missing] set addr to 43
    data_in = 171;// [Missing] set the data_in to value of data to 171
    // this value is AB in hex (You will see this in gtkwave)
    rw = 0;// [Missing] set rw to 0

    enable = 1;// [Missing] set enable
    wait(7, SC_NS);// [Missing] wait 7 NS
    i2c_sda = (sc_logic)0;// [Missing] set i2c_sda to logic 0

    wait(10,SC_NS);// [Missing] wait 10 NS
    enable = 0;// [Missing] reset enable (=0)
    wait(500, SC_NS);// [Missing]wait for 500 NS 
    
    
    //slave 3
    addr=44;// [Missing] set addr to 43
    data_in = 172;// [Missing] set the data_in to value of data to 171
    // this value is AB in hex (You will see this in gtkwave)
    rw = 0;// [Missing] set rw to 0
    
    enable = 1;// [Missing] set enable
    wait(7, SC_NS);// [Missing] wait 7 NS
    i2c_sda = (sc_logic)0;// [Missing] set i2c_sda to logic 0
    
    wait(10,SC_NS);// [Missing] wait 10 NS
    enable = 0;// [Missing] reset enable (=0)
    wait(500, SC_NS);// [Missing]wait for 500 NS
    
    
    // slave 4
    addr=45;// [Missing] set addr to 43
    data_in = 173;// [Missing] set the data_in to value of data to 171
    // this value is AB in hex (You will see this in gtkwave)
    rw = 0;// [Missing] set rw to 0
    
    enable = 1;// [Missing] set enable
    wait(7, SC_NS);// [Missing] wait 7 NS
    i2c_sda = (sc_logic)0;// [Missing] set i2c_sda to logic 0
    
    wait(10,SC_NS);// [Missing] wait 10 NS
    enable = 0;// [Missing] reset enable (=0)
    wait(500, SC_NS);// [Missing]wait for 500 NS 
}
