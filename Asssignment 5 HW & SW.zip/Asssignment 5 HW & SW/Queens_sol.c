#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define  nil		0
#define	 false		0
#define  true		1
#define  MMsize         10


// NOTE: Do not change this function.
void Try(int i, int *q, int a[], int b[], int c[], int x[]) {
	int     j;
	j = 0;
	*q = false;
	while ( (! *q) && (j != 8) ) {
		j = j + 1;
		*q = false;
		if ( b[j] && a[i+j] && c[i-j+7] ) {
			x[i] = j;
		    b[j] = false;
		    a[i+j] = false;
		    c[i-j+7] = false;
		    if ( i < 8 ) {
		    	Try(i+1,q,a,b,c,x);
				if ( ! *q ) {
					b[j] = true;
				    a[i+j] = true;
				    c[i-j+7] = true;
				}
			}
		    else *q = true;
	    }
	}
}


//lowest
int SumProduct(int a, int b, int c) {
    int prod = b * c;
    int sum = a + prod;
    return sum;
}

void Doit() {
    // Initialize variables
    int i, q, sum = 0;
    int a[9] = {0}, b[17] = {0}, c[15] = {0}, x[9] = {0};
    int W[MMsize][MMsize], U[MMsize][MMsize][MMsize], V[MMsize][MMsize][MMsize];

    // Initialize values of a, b, and c
    for (i = 1; i <= 8; i++) {
        a[i] = true;
    }
    for (i = 2; i <= 16; i++) {
        b[i] = true;
    }
    for (i = -7; i <= 7; i++) {
        c[i + 7] = true;
    }

    // Solve the Queens problem
    Try(1, &q, b, a, c, x);
    if (!q) {
        printf("Error in Queens.\n");
        return;
    }

    // Initialize values of W and U
    for (i = 0; i < MMsize; i++) {
        for (int j = 0; j < MMsize; j++) {
            W[i][j] = (i % 2 == 0 && j % 2 == 0) ? 3 : 2;
        }
    }
    for (i = 0; i < MMsize; i++) {
        for (int j = 0; j < MMsize; j++) {
            for (int k = 0; k < MMsize; k++) {
                U[i][j][k] = (i % 2 == 0 && j % 2 == 0 && k % 2 == 0) ? 7 : 4;
            }
        }
    }

    // Calculate the value of V using SumProduct function
    for (i = 0; i < MMsize; i++) {
        for (int j = 0; j < MMsize; j++) {
            for (int g = 0; g < MMsize; g++) {
                int tempSum = 0;
                for (int k = 0; k < MMsize; k++) {
                    tempSum += W[i][k] * U[k][j][g];
                }
                V[i][j][g] = tempSum;
            }
        }
    }

    // Calculate the sum of all values in V
    for (i = 0; i < MMsize; i++) {
        for (int j = 0; j < MMsize; j++) {
            for (int k = 0; k < MMsize; k++) {
                sum += V[i][j][k];
            }
        }
    }

    // Print the final sum
    printf("sum: %d", sum);
}
// NOTE: Do not change this function
void Queens (int run) {
    int i;
    // NOTE: Do not reduce/change the number of iterations in the loop below
    Doit();
    printf("%d\n", run + 1);
}

// NOTE: Do not change this function
int main()
{
	int i;
	// NOTE: Do not reduce/change the number of iterations in the loop below
	for (i = 0; i < 50; i++) Queens(i);
	return 0;
}
